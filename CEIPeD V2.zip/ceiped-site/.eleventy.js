// ============================================================
// Configuración de Eleventy — CEIPeD
// Define cómo se arman las páginas a partir del contenido.
// No necesitás tocar este archivo para cargar contenido.
// ============================================================

module.exports = function (eleventyConfig) {
  // Copiar tal cual las carpetas de assets y el panel /admin
  // (forma objeto: se publican en /assets y /admin, no en /src/...)
  eleventyConfig.addPassthroughCopy({ "src/assets": "assets" });
  eleventyConfig.addPassthroughCopy({ "src/admin": "admin" });

  // ---- Colecciones ordenadas ----
  eleventyConfig.addCollection("publicaciones", (c) =>
    c.getFilteredByTag("publicaciones").sort((a, b) => b.data.fecha - a.data.fecha)
  );
  eleventyConfig.addCollection("equipo", (c) =>
    c.getFilteredByTag("equipo").filter((i) => i.data.activo !== false)
  );
  eleventyConfig.addCollection("areas", (c) =>
    c.getFilteredByTag("areas").sort((a, b) => (a.data.numero || 0) - (b.data.numero || 0))
  );
  eleventyConfig.addCollection("programas", (c) => c.getFilteredByTag("programas"));

  // ---- Filtros de ayuda para las plantillas ----
  // Buscar un item por su slug de archivo (para resolver autor por slug)
  eleventyConfig.addFilter("findItem", (collection, slug) =>
    (collection || []).find((i) => i.fileSlug === slug)
  );
  // Buscar un item por su campo "nombre" (para resolver el área)
  eleventyConfig.addFilter("findByName", (collection, nombre) =>
    (collection || []).find((i) => i.data.nombre === nombre)
  );
  // Publicaciones de un área (por nombre)
  eleventyConfig.addFilter("byArea", (pubs, nombre) =>
    (pubs || []).filter((p) => p.data.area === nombre)
  );
  // Publicaciones de un autor (por slug)
  eleventyConfig.addFilter("byAuthor", (pubs, slug) =>
    (pubs || []).filter((p) => p.data.autor === slug)
  );
  // Miembros del equipo por categoría
  eleventyConfig.addFilter("byCategoria", (eq, cat) =>
    (eq || []).filter((m) => m.data.categoria === cat)
  );
  // Miembros cuyo listado de áreas incluye un área dada
  eleventyConfig.addFilter("byAreaTag", (eq, nombre) =>
    (eq || []).filter((m) => Array.isArray(m.data.areas) && m.data.areas.indexOf(nombre) !== -1)
  );
  // Limitar y excluir
  eleventyConfig.addFilter("limit", (arr, n) => (arr || []).slice(0, n));
  eleventyConfig.addFilter("exclude", (arr, slug) =>
    (arr || []).filter((i) => i.fileSlug !== slug)
  );
  // Solo las marcadas como destacadas
  eleventyConfig.addFilter("destacadas", (arr) =>
    (arr || []).filter((p) => p.data.destacado)
  );
  // Sub-rango de un array (start incluido, end excluido)
  eleventyConfig.addFilter("sliceRange", (arr, start, end) =>
    (arr || []).slice(start, end)
  );

  // Fecha legible en español: 28 May 2026
  const MESES = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
  eleventyConfig.addFilter("fecha", (d) => {
    if (!d) return "";
    const x = new Date(d);
    return `${x.getUTCDate()} ${MESES[x.getUTCMonth()]} ${x.getUTCFullYear()}`;
  });
  // Fecha larga: 28 de mayo de 2026
  const MESES_L = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
  eleventyConfig.addFilter("fechaLarga", (d) => {
    if (!d) return "";
    const x = new Date(d);
    return `${x.getUTCDate()} de ${MESES_L[x.getUTCMonth()]} de ${x.getUTCFullYear()}`;
  });

  return {
    markdownTemplateEngine: "njk",
    htmlTemplateEngine: "njk",
    dir: {
      input: "src",
      includes: "_includes",
      data: "_data",
      output: "_site",
    },
  };
};
